package com.jupiter.jupiterback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JupiterbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
